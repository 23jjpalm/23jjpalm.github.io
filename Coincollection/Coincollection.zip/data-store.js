const CoinDataStore = (() => {
  const STORAGE_KEYS = {
    coins: "coins",
    stories: "coinStories",
    bullionOz: "bullionOz",
    initialized: "coinSiteInitialized"
  };

  const DEFAULT_BULLION_OZ = 13;

  const DEFAULT_COINS = [
    { "id": 1, "year": 1877, "denomination": "Dime", "quantity": 1 },
    { "id": 2, "year": 1883, "denomination": "Dime", "quantity": 1 },
    { "id": 3, "year": 1883, "denomination": "Dollar Coin", "quantity": 1 },
    { "id": 4, "year": 1884, "denomination": "Dollar Coin", "quantity": 1 },
    { "id": 5, "year": 1903, "denomination": "Quarter (Barber)", "quantity": 1 },
    { "id": 6, "year": 1911, "denomination": "Half Dollar", "quantity": 1 },
    { "id": 7, "year": 1917, "denomination": "Mercury Dime", "quantity": 1 },
    { "id": 8, "year": 1928, "denomination": "Buffalo Nickel", "quantity": 1 },
    { "id": 9, "year": 1934, "denomination": "Half Dollar", "quantity": 1 },
    { "id": 10, "year": 1935, "denomination": "Mercury Dime", "quantity": 3 },
    { "id": 11, "year": 1936, "denomination": "Mercury Dime", "quantity": 4 },
    { "id": 12, "year": 1936, "denomination": "Buffalo Nickel", "quantity": 1 },
    { "id": 13, "year": 1938, "denomination": "Mercury Dime", "quantity": 2 },
    { "id": 14, "year": 1939, "denomination": "Mercury Dime", "quantity": 4 },
    { "id": 15, "year": 1940, "denomination": "Mercury Dime", "quantity": 1 },
    { "id": 16, "year": 1940, "denomination": "Quarter", "quantity": 1 },
    { "id": 17, "year": 1941, "denomination": "Mercury Dime", "quantity": 5 },
    { "id": 18, "year": 1941, "denomination": "Quarter", "quantity": 1 },
    { "id": 19, "year": 1942, "denomination": "Mercury Dime", "quantity": 14 },
    { "id": 20, "year": 1942, "denomination": "Quarter", "quantity": 2 },
    { "id": 21, "year": 1943, "denomination": "Mercury Dime", "quantity": 10 },
    { "id": 22, "year": 1944, "denomination": "Mercury Dime", "quantity": 8 },
    { "id": 23, "year": 1945, "denomination": "Mercury Dime", "quantity": 5 },
    { "id": 24, "year": 1946, "denomination": "Roosevelt Dime", "quantity": 4 },
    { "id": 25, "year": 1947, "denomination": "Roosevelt Dime", "quantity": 2 },
    { "id": 26, "year": 1948, "denomination": "Roosevelt Dime", "quantity": 2 },
    { "id": 27, "year": 1948, "denomination": "Quarter", "quantity": 1 },
    { "id": 28, "year": 1951, "denomination": "Roosevelt Dime", "quantity": 1 },
    { "id": 29, "year": 1952, "denomination": "Roosevelt Dime", "quantity": 1 },
    { "id": 30, "year": 1952, "denomination": "Half Dollar", "quantity": 1 },
    { "id": 31, "year": 1953, "denomination": "Quarter", "quantity": 1 },
    { "id": 32, "year": 1954, "denomination": "Roosevelt Dime", "quantity": 2 },
    { "id": 33, "year": 1956, "denomination": "Roosevelt Dime", "quantity": 1 },
    { "id": 34, "year": 1957, "denomination": "Roosevelt Dime", "quantity": 1 },
    { "id": 35, "year": 1958, "denomination": "Quarter", "quantity": 1 },
    { "id": 36, "year": 1959, "denomination": "Roosevelt Dime", "quantity": 1 },
    { "id": 37, "year": 1959, "denomination": "Quarter", "quantity": 1 },
    { "id": 38, "year": 1961, "denomination": "Roosevelt Dime", "quantity": 5 },
    { "id": 39, "year": 1962, "denomination": "Roosevelt Dime", "quantity": 3 },
    { "id": 40, "year": 1963, "denomination": "Roosevelt Dime", "quantity": 4 },
    { "id": 41, "year": 1963, "denomination": "Quarter", "quantity": 2 },
    { "id": 42, "year": 1964, "denomination": "Roosevelt Dime", "quantity": 13 },
    { "id": 43, "year": 1964, "denomination": "Quarter", "quantity": 2 },
    { "id": 44, "year": 1964, "denomination": "Half Dollar", "quantity": 2 },
    { "id": 45, "year": 1966, "denomination": "Half Dollar", "quantity": 1 },
    { "id": 46, "year": 1967, "denomination": "Half Dollar", "quantity": 2 }
  ];

  function getCoinSpec(year, denomination) {
    if (denomination === "Fine Silver") return { silverContent: 100, weightGrams: 31.1035 };
    if (denomination === "Buffalo Nickel") return { silverContent: 0, weightGrams: 5.0 };

    if (
      denomination === "Dime" ||
      denomination === "Mercury Dime" ||
      denomination === "Roosevelt Dime"
    ) {
      return { silverContent: 90, weightGrams: 2.5 };
    }

    if (denomination === "Quarter" || denomination === "Quarter (Barber)") {
      return { silverContent: 90, weightGrams: 6.25 };
    }

    if (denomination === "Dollar Coin") {
      return { silverContent: 90, weightGrams: 26.73 };
    }

    if (denomination === "Half Dollar") {
      if (year === 1966 || year === 1967) {
        return { silverContent: 40, weightGrams: 11.5 };
      }
      return { silverContent: 90, weightGrams: 12.5 };
    }

    return { silverContent: 0, weightGrams: 0 };
  }

  function safeParse(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) return fallback;
      const parsed = JSON.parse(raw);
      return parsed ?? fallback;
    } catch {
      return fallback;
    }
  }

  function enrichCoin(coin) {
    const spec = getCoinSpec(Number(coin.year), coin.denomination);

    const weightGrams =
      typeof coin.customWeightGrams === "number"
        ? coin.customWeightGrams
        : (typeof coin.weightGrams === "number" ? coin.weightGrams : spec.weightGrams);

    const silverContent =
      typeof coin.customSilverContent === "number"
        ? coin.customSilverContent
        : (typeof coin.silverContent === "number" ? coin.silverContent : spec.silverContent);

    return {
      notes: "",
      weightUnit: "g",
      personalStory: "",
      ...coin,
      year: Number(coin.year),
      quantity: Number(coin.quantity),
      silverContent,
      weightGrams
    };
  }

  function initializeIfNeeded(force = false) {
    const initialized = localStorage.getItem(STORAGE_KEYS.initialized) === "true";

    if (!initialized || force) {
      const currentStories = safeParse(STORAGE_KEYS.stories, {});
      const currentBullion = Number(localStorage.getItem(STORAGE_KEYS.bullionOz));

      localStorage.setItem(
        STORAGE_KEYS.coins,
        JSON.stringify(DEFAULT_COINS.map(enrichCoin))
      );

      if (!localStorage.getItem(STORAGE_KEYS.stories) || force) {
        localStorage.setItem(STORAGE_KEYS.stories, JSON.stringify(currentStories));
      }

      if (!Number.isFinite(currentBullion) || force) {
        localStorage.setItem(STORAGE_KEYS.bullionOz, String(DEFAULT_BULLION_OZ));
      }

      localStorage.setItem(STORAGE_KEYS.initialized, "true");
    }
  }

  function getCoins() {
    initializeIfNeeded();
    return safeParse(STORAGE_KEYS.coins, DEFAULT_COINS).map(enrichCoin);
  }

  function saveCoins(coins) {
    localStorage.setItem(
      STORAGE_KEYS.coins,
      JSON.stringify(coins.map(enrichCoin))
    );
  }

  function getStories() {
    initializeIfNeeded();
    return safeParse(STORAGE_KEYS.stories, {});
  }

  function saveStories(stories) {
    localStorage.setItem(STORAGE_KEYS.stories, JSON.stringify(stories || {}));
  }

  function saveStory(key, value) {
    const stories = getStories();
    stories[key] = value;
    saveStories(stories);
  }

  function getBullionOz() {
    initializeIfNeeded();
    const value = Number(localStorage.getItem(STORAGE_KEYS.bullionOz));
    return Number.isFinite(value) ? value : DEFAULT_BULLION_OZ;
  }

  function saveBullionOz(value) {
    const oz = Number(value);
    localStorage.setItem(
      STORAGE_KEYS.bullionOz,
      String(Number.isFinite(oz) ? oz : DEFAULT_BULLION_OZ)
    );
  }

  function nextCoinId(coins = getCoins()) {
    return coins.reduce((max, coin) => Math.max(max, Number(coin.id) || 0), 0) + 1;
  }

  return {
    STORAGE_KEYS,
    DEFAULT_BULLION_OZ,
    DEFAULT_COINS,
    getCoinSpec,
    initializeIfNeeded,
    getCoins,
    saveCoins,
    getStories,
    saveStories,
    saveStory,
    getBullionOz,
    saveBullionOz,
    nextCoinId
  };
})();
